version="0.1"
tags={
	"Graphics"
	"Map"
}
name="Valsora: Victorianization Patch"
supported_version="1.19.*"
picture="thumbnail.png"
dependencies={
	"Victorianization (Universal Compatibility)"
	"Valsora (test map)"
}
path="mod/valsora_victorianization"

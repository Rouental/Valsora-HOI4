-- Valsora: Atlas. Graphics defines for a printed-atlas look.
-- Map modes draw an opaque colour over the land and the sea; at 1 it is transparent,
-- so the paper, the waterlines and the sea lettering show (the first in-game test,
-- 2026-10-07, without these: flat grey sea, country colours over grey).
NDefines_Graphics.NMapMode.MAP_MODE_TERRAIN_TRANSPARENCY = 1
NDefines_Graphics.NMapMode.MAP_MODE_NAVAL_TERRAIN_TRANSPARENCY = 1
-- Countries: the whole country washed in its colour, with a narrow band inside the
-- border (a wide one is drawn on a coarse grid and shows steps).
NDefines_Graphics.NGraphics.GRADIENT_BORDERS_FIELD_COUNTRY_LOW = 9000.0
NDefines_Graphics.NGraphics.GRADIENT_BORDERS_FIELD_COUNTRY_HIGH = 9000.0
NDefines_Graphics.NGraphics.GRADIENT_BORDERS_THICKNESS_COUNTRY_LOW = 2.0
NDefines_Graphics.NGraphics.GRADIENT_BORDERS_THICKNESS_COUNTRY_HIGH = 9.0
-- Province lines only up close, state lines a little further out, as an atlas shows
-- smaller divisions only on its larger-scale plates.
NDefines_Graphics.NGraphics.PROVINCE_BORDER_FADE_NEAR = 260
NDefines_Graphics.NGraphics.PROVINCE_BORDER_FADE_FAR = 320
NDefines_Graphics.NGraphics.STATE_BORDER_FADE_NEAR = 620
NDefines_Graphics.NGraphics.STATE_BORDER_FADE_FAR = 720
-- Paper doesn't glow.
NDefines_Graphics.NGraphics.BLOOM_SCALE = 0.0

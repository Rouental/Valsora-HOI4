-- Valsora: Atlas. Graphics defines for a printed-atlas look.
-- Countries: the whole country washed in its colour, with a stronger band inside the
-- border, at every zoom level (the field reaches everywhere; the band is in pixels).
NDefines_Graphics.NGraphics.GRADIENT_BORDERS_FIELD_COUNTRY_LOW = 9000.0
NDefines_Graphics.NGraphics.GRADIENT_BORDERS_FIELD_COUNTRY_HIGH = 9000.0
NDefines_Graphics.NGraphics.GRADIENT_BORDERS_THICKNESS_COUNTRY_LOW = 6.0
NDefines_Graphics.NGraphics.GRADIENT_BORDERS_THICKNESS_COUNTRY_HIGH = 26.0
-- Province lines only up close, state lines a little further out, as an atlas shows
-- smaller divisions only on its larger-scale plates.
NDefines_Graphics.NGraphics.PROVINCE_BORDER_FADE_NEAR = 260
NDefines_Graphics.NGraphics.PROVINCE_BORDER_FADE_FAR = 320
NDefines_Graphics.NGraphics.STATE_BORDER_FADE_NEAR = 620
NDefines_Graphics.NGraphics.STATE_BORDER_FADE_FAR = 720
-- Paper doesn't glow.
NDefines_Graphics.NGraphics.BLOOM_SCALE = 0.0

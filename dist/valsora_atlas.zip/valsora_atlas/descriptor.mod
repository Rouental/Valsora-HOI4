version="1.0"
tags={
	"Graphics"
	"Map"
}
name="Valsora: Atlas"
supported_version="1.19.*"
picture="thumbnail.png"
dependencies={
	"Valsora (test map)"
}

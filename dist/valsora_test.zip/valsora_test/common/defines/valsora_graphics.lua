-- the minimap slides this far right to hide it (vanilla 270, for its wider minimap)
NDefines_Graphics.NInterface.MINIMAP_TOGGLE_SHIFT = 202

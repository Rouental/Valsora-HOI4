-- Valsora takes place in 2036 (scripts/vanilla_parts.py)
NDefines.NGame.START_DATE = "2036.1.1.12"
NDefines.NGame.END_DATE = "2049.1.1.1"
NDefines.NDiplomacy.TENSION_TIME_SCALE_START_DATE = "2036.1.1.12"

version="0.1"
tags={
	"Graphics"
	"Map"
}
name="Valsora: Cartographic Map"
supported_version="1.19.*"
picture="thumbnail.png"
dependencies={
	"Valsora (test map)"
}
path="mod/valsora_cartographic"
